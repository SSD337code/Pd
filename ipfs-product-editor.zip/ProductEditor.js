import { useState, useEffect, useRef } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ethers } from "ethers";
import { Web3Storage } from "web3.storage";

export default function ProductEditor() {
  const [product, setProduct] = useState({
    name: "",
    title: "",
    description: "",
    fullDescription: "",
    price: "",
    currency: "CNY",
    categories: "",
    image: ""
  });

  const [walletAddress, setWalletAddress] = useState(null);
  const fileInputRef = useRef(null);

  const token = import.meta.env.VITE_WEB3STORAGE_TOKEN;
  const client = new Web3Storage({ token });

  useEffect(() => {
    if (window.ethereum) {
      window.ethereum.on("accountsChanged", (accounts) => {
        setWalletAddress(accounts[0] || null);
      });
    }
  }, []);

  const connectWallet = async () => {
    if (typeof window.ethereum !== "undefined") {
      try {
        const accounts = await window.ethereum.request({ method: "eth_requestAccounts" });
        setWalletAddress(accounts[0]);
      } catch (err) {
        console.error("Wallet connection failed:", err);
      }
    } else {
      alert("請安裝 MetaMask 或其他以太坊錢包。");
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setProduct((prev) => ({ ...prev, [name]: value }));
  };

  const uploadToIPFS = async (file) => {
    const cid = await client.put([file]);
    const url = `https://${cid}.ipfs.w3s.link/${file.name}`;
    setProduct((prev) => ({ ...prev, image: url }));
  };

  const handleDrop = async (e) => {
    e.preventDefault();
    const file = e.dataTransfer.files[0];
    if (file) {
      await uploadToIPFS(file);
    }
  };

  const handleDragOver = (e) => {
    e.preventDefault();
  };

  const handleFileSelect = async (e) => {
    const file = e.target.files[0];
    if (file) {
      await uploadToIPFS(file);
    }
  };

  const handleSubmit = () => {
    if (!walletAddress) {
      alert("請先連接錢包以匿名上架商品。");
      return;
    }

    const formattedProduct = {
      ...product,
      price: product.price.toString(),
      quantity: 1,
      outOfStock: false,
      isFeatured: false,
      categories: product.categories.split(",").map((id) => id.trim()),
      images: product.image ? [{ url: product.image }] : [],
      created: Date.now(),
      updated: Date.now(),
      isDefault: false,
    };
    console.log("📦 商品上架：", formattedProduct);
  };

  return (
    <div className="p-4 max-w-2xl mx-auto">
      <Card className="mb-4">
        <CardContent className="space-y-4">
          {!walletAddress ? (
            <Button onClick={connectWallet}>🔐 匿名登入（錢包）</Button>
          ) : (
            <div className="text-sm text-green-600">✅ 已連接：{walletAddress}</div>
          )}
          <Input name="name" placeholder="商品名稱" onChange={handleChange} />
          <Input name="title" placeholder="顯示標題" onChange={handleChange} />
          <Textarea name="description" placeholder="簡短描述" onChange={handleChange} />
          <Textarea name="fullDescription" placeholder="詳細說明" onChange={handleChange} />
          <Input name="price" type="number" placeholder="價格" onChange={handleChange} />
          <Input name="currency" placeholder="幣別（如 CNY, TWD）" onChange={handleChange} />
          <Input name="categories" placeholder="分類ID（以逗號分隔）" onChange={handleChange} />
          <div 
            className="border-2 border-dashed p-4 rounded-xl text-center cursor-pointer"
            onDrop={handleDrop}
            onDragOver={handleDragOver}
            onClick={() => fileInputRef.current?.click()}
          >
            {product.image ? (
              <img src={product.image} alt="預覽圖片" className="mx-auto max-h-48 rounded" />
            ) : (
              <span className="text-gray-500">拖曳或點擊選擇圖片</span>
            )}
            <input 
              ref={fileInputRef} 
              type="file" 
              accept="image/*" 
              onChange={handleFileSelect} 
              hidden 
            />
          </div>
          <Button onClick={handleSubmit}>📤 上架商品</Button>
        </CardContent>
      </Card>
    </div>
  );
}