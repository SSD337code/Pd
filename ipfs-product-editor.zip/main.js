
import React from "https://cdn.skypack.dev/react";
import ReactDOM from "https://cdn.skypack.dev/react-dom";
import ProductEditor from "./ProductEditor.js";

ReactDOM.render(React.createElement(ProductEditor), document.getElementById("root"));
